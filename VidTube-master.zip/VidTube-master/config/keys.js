//we can this file to .gitignore to not upload this file so our secrects are not shared
module.exports = {
    google:{
        clientID:'981460578481-mua4ebu6mg740kj7b4o7fmem5c8cna89.apps.googleusercontent.com',
        clientSecret:'yBl7mi9dNddLf3HaYuGvQlrU'
    },
    session:{
        cookieKey:"Sudhanshu"
    }
}