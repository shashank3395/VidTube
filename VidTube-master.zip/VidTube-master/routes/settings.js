const express = require('express');
//const Settings = require('../controllers/settings');
var router = express.Router();

// router.get('/forgot',Settings.forgotPage);
// router.post('/forgot',Settings.forgot);

module.exports = router;
